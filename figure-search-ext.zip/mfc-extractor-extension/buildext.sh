cd ~/WebstormProjects/figure-search
npm run build
cd ~/
